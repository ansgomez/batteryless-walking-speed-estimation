#ifndef DMA_H_
#define DMA_H_

//void DMA_init(void);

void DMA_ISR(void);

#endif /* DMA_H_ */
