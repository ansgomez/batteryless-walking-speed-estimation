#ifndef WATCHDOG_H_
#define WATCHDOG_H_


void Watchdog_init(void);


#endif /* WATCHDOG_H_ */
